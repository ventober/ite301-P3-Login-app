package com.android.employeelogin;
import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
public class SQLiteHelper extends SQLiteOpenHelper {
    static String DATABASE_NAME="EmployeesDB";
    public static final String TABLE_NAME="Employees";
    public static final String ID="id";
    public static final String EMPLOYEE_NAME="employeename";
    public static final String EMAIL="email";
    public static final String PASSWORD="password";
    public SQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase database) {
        String CREATE_TABLE="CREATE TABLE IF NOT EXISTS "+TABLE_NAME+" ("+ID+" INTEGER
        PRIMARY KEY, "+EMPLOYEE_NAME+" VARCHAR, "+EMAIL+" VARCHAR, "+PASSWORD+" VARCHAR)";
        database.execSQL(CREATE_TABLE);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }
}