package com.android.employeelogin;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
public class RegistrationActivity extends AppCompatActivity {
    EditText EmployeeName, Email, Password;
    Button buttonRegister;
    String EmployeeNameHolder, EmailHolder, PasswordHolder;
    Boolean emptyHolder;
    SQLiteDatabase sqLiteDatabaseObj;
    String SQLiteDataBaseQueryHolder ;
    SQLiteHelper sqLiteHelper;
    Cursor cursor;
    String F_Result = "Not_Found";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        TextView login = (TextView)findViewById(R.id.lnkLogin);
        login.setMovementMethod(LinkMovementMethod.getInstance());
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegistrationActivity.this,
                        MainActivity.class);
                startActivity(intent);
            }
        });
        buttonRegister = (Button)findViewById(R.id.buttonRegister);
        EmployeeName = (EditText)findViewById(R.id.editTextName);
        Email = (EditText)findViewById(R.id.editTextEmail);
        Password = (EditText)findViewById(R.id.editTextPassword);
        sqLiteHelper = new SQLiteHelper(this);
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDataBaseBuild();
                SQLiteTableBuild();
                verifyEntry();
                checkEmail();
                clearEntry();
            }
        });
    }
    public void SQLiteDataBaseBuild(){
        sqLiteDatabaseObj = openOrCreateDatabase(SQLiteHelper.DATABASE_NAME,
                Context.MODE_PRIVATE, null);
    }

    public void SQLiteTableBuild() {
        sqLiteDatabaseObj.execSQL("CREATE TABLE IF NOT EXISTS " +
                        SQLiteHelper.TABLE_NAME + "(" + SQLiteHelper.ID + " INTEGER PRIMARY KEY AUTOINCREMENT
                NOT NULL, " + SQLiteHelper.EMPLOYEE_NAME + " VARCHAR, " + SQLiteHelper.EMAIL + "
                VARCHAR, " + SQLiteHelper.PASSWORD + " VARCHAR);");
    }
    public void saveRegistration(){
        if(emptyHolder == true) {
            SQLiteDataBaseQueryHolder = "INSERT INTO "+SQLiteHelper.TABLE_NAME+"
            (employeename,email,password) VALUES('"+EmployeeNameHolder+"', '"+EmailHolder+"',
                    '"+PasswordHolder+"');";
            sqLiteDatabaseObj.execSQL(SQLiteDataBaseQueryHolder);
            sqLiteDatabaseObj.close();
            Toast.makeText(RegistrationActivity.this,"Employee registered
                    successfully!", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(RegistrationActivity.this,"All fields must be filled!",
                    Toast.LENGTH_LONG).show();
        }
    }
    public void clearEntry(){
        EmployeeName.getText().clear();
        Email.getText().clear();
        Password.getText().clear();
    }
    public void verifyEntry(){
        EmployeeNameHolder = EmployeeName.getText().toString() ;
        EmailHolder = Email.getText().toString();
        PasswordHolder = Password.getText().toString();
        if(TextUtils.isEmpty(EmployeeNameHolder) || TextUtils.isEmpty(EmailHolder) ||
                TextUtils.isEmpty(PasswordHolder)){
            emptyHolder = false ;
        } else {
            emptyHolder = true ;
        }
    }
    public void checkEmail(){
        sqLiteDatabaseObj = sqLiteHelper.getWritableDatabase();
        cursor = sqLiteDatabaseObj.query(SQLiteHelper.TABLE_NAME, null, " " +
                SQLiteHelper.EMAIL+ "=?", new String[]{EmailHolder}, null, null, null);
        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();
                F_Result = "Email Found";

                cursor.close();
            }
        }
        checkResult();
    }
    public void checkResult(){
        if(F_Result.equalsIgnoreCase("Email Found")) {
            Toast.makeText(RegistrationActivity.this,"Email already
                    exists!",Toast.LENGTH_LONG).show();
        } else {
            saveRegistration();
        }
        F_Result = "Not_Found" ;
    }
}