package com.android.employeelogin;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
public class DashboardActivity extends AppCompatActivity {
    String EmailHolder;
    TextView Email;
    Button buttonLogout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        Email = (TextView)findViewById(R.id.textView1);
        buttonLogout = (Button)findViewById(R.id.buttonLogout);
        Intent intent = getIntent();
        EmailHolder = intent.getStringExtra(MainActivity.EmployeeEmail);
        Email.setText(Email.getText().toString()+EmailHolder);
        buttonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();

                Toast.makeText(DashboardActivity.this,"Successfully logged out!",

                        Toast.LENGTH_LONG).show();
            }
        });
    }
}