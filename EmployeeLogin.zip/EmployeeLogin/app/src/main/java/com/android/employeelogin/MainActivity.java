package com.android.employeelogin;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    Button buttonLogin;
    EditText Email, Password;
    String EmailHolder, PasswordHolder;
    Boolean emptyHolder;
    SQLiteDatabase sqLiteDatabaseObj;
    SQLiteHelper sqLiteHelper;
    Cursor cursor;
    String TempPassword = "NOT_FOUND" ;
    public static final String EmployeeEmail = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonLogin = (Button)findViewById(R.id.buttonLogin);
        Email = (EditText)findViewById(R.id.editTextEmail);
        Password = (EditText)findViewById(R.id.editTextPassword);
        sqLiteHelper = new SQLiteHelper(this);
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validateEntry();
                loginEmployee();
            }
        });

        TextView register = (TextView)findViewById(R.id.linkRegister);
        register.setMovementMethod(LinkMovementMethod.getInstance());
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,
                        RegistrationActivity.class);
                startActivity(intent);
            }
        });
    }
    public void loginEmployee(){
        if(emptyHolder) {
            sqLiteDatabaseObj = sqLiteHelper.getWritableDatabase();
            cursor = sqLiteDatabaseObj.query(SQLiteHelper.TABLE_NAME, null, " " +
                    SQLiteHelper.EMAIL+ "=?", new String[]{EmailHolder}, null, null, null);
            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();
                    TempPassword =

                            cursor.getString(cursor.getColumnIndex(SQLiteHelper.PASSWORD));
                    cursor.close();
                }
            }
            CheckFinalResult();
        }
        else {
            Toast.makeText(MainActivity.this,"Please enter email or
                    password.",Toast.LENGTH_LONG).show();
        }
    }
    public void validateEntry(){
        EmailHolder = Email.getText().toString();
        PasswordHolder = Password.getText().toString();
        if(TextUtils.isEmpty(EmailHolder) || TextUtils.isEmpty(PasswordHolder)){
            emptyHolder = false ;
        } else {
            emptyHolder = true ;
        }
    }
    public void CheckFinalResult(){
        if(TempPassword.equalsIgnoreCase(PasswordHolder)){
            Toast.makeText(MainActivity.this,"Welcome! You logged in
                    successfully!",Toast.LENGTH_LONG).show();
            Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
            intent.putExtra(EmailHolder, EmailHolder);
            startActivity(intent);
        } else {
            Toast.makeText(MainActivity.this,"Email or Password is incorrect, please
                    Try Again.",Toast.LENGTH_LONG).show();
        }
        TempPassword = "NOT_FOUND" ;
    }
}