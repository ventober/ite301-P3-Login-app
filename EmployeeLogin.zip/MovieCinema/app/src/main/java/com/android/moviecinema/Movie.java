package com.android.moviecinema;
public class Movie {
    int id;
    String title;
    String genre;
    String director;
    public Movie(){
    }
}