package com.android.moviecinema;
import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class OnClickListenerCreateMovie implements View.OnClickListener {
    @Override
    public void onClick(View view) {
        final Context context = view.getRootView().getContext();
        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View formElementsView =
                inflater.inflate(R.layout.movie_input_form, null, false);
        final EditText editTextTitle = (EditText)
                formElementsView.findViewById(R.id.editTextTitle);
        final EditText editTextGenre = (EditText)
                formElementsView.findViewById(R.id.editTextGenre);
        final EditText editTextDirector = (EditText)
                formElementsView.findViewById(R.id.editTextDirector);
        new AlertDialog.Builder(context)
                .setView(formElementsView)
                .setTitle("Add Movie")
                .setPositiveButton("Save",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int
                                    id) {
                                String movieTitle =
                                        editTextTitle.getText().toString();

                                String movieGenre =

                                        editTextGenre.getText().toString();

                                String movieDirector =

                                        editTextDirector.getText().toString();
                                Movie movie = new Movie();
                                movie.title = movieTitle;
                                movie.genre = movieGenre;
                                movie.director = movieDirector;
                                boolean createSuccessful = new

                                        TableControllerMovie(context).create(movie);
                                MainActivity.getInstance().countRecords();
                                MainActivity.getInstance().readRecords();
                                if(createSuccessful){

                                    Toast.makeText(context, "Movie record was
                                            saved.", Toast.LENGTH_SHORT).show();
                                }else{
                                    Toast.makeText(context, "Error saving
                                            movie record.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }).show();
    }
}