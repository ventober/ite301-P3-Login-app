package com.android.moviecinema;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;
public class TableControllerMovie extends DatabaseHandler {
    public TableControllerMovie(Context context) {
        super(context);
    }

    public boolean create(Movie movie) {
        ContentValues values = new ContentValues();
        values.put("title", movie.title);
        values.put("genre", movie.genre);
        values.put("director", movie.director);
        SQLiteDatabase db = this.getWritableDatabase();
        boolean createSuccessful = db.insert("movies", null, values) > 0;
        db.close();
        return createSuccessful;
    }
    public int count() {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "SELECT * FROM movies";
        int recordCount = db.rawQuery(sql, null).getCount();
        db.close();
        return recordCount;
    }
    public List<Movie> read() {
        List<Movie> recordsList = new ArrayList<Movie>();
        String sql = "SELECT * FROM movies ORDER BY id DESC";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                int id =
                        Integer.parseInt(cursor.getString(cursor.getColumnIndex("id")));
                String title = cursor.getString(cursor.getColumnIndex("Title"));
                String genre = cursor.getString(cursor.getColumnIndex("genre"));
                String director =
                        cursor.getString(cursor.getColumnIndex("director"));
                Movie movie = new Movie();
                movie.id = id;
                movie.title = title;
                movie.genre = genre;
                movie.director = director;
                recordsList.add(movie);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return recordsList;
    }

    public Movie readSingleRecord(int movieId) {
        Movie movie = null;
        String sql = "SELECT * FROM movies WHERE id = " + movieId;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            int id =
                    Integer.parseInt(cursor.getString(cursor.getColumnIndex("id")));
            String title = cursor.getString(cursor.getColumnIndex("title"));
            String genre = cursor.getString(cursor.getColumnIndex("genre"));
            String director =
                    cursor.getString(cursor.getColumnIndex("director"));
            movie = new Movie();
            movie.id = id;
            movie.title = title;
            movie.genre = genre;
            movie.director = director;
        }
        cursor.close();
        db.close();
        return movie;
    }
    public boolean update(Movie movie) {
        ContentValues values = new ContentValues();
        values.put("title", movie.title);
        values.put("genre", movie.genre);
        values.put("director", movie.director);
        String where = "id = ?";
        String[] whereArgs = { Integer.toString(movie.id) };
        SQLiteDatabase db = this.getWritableDatabase();
        boolean updateSuccessful = db.update("movies", values, where, whereArgs)
                > 0;
        db.close();
        return updateSuccessful;
    }
    public boolean delete(int id) {
        boolean deleteSuccessful = false;
        SQLiteDatabase db = this.getWritableDatabase();
        deleteSuccessful = db.delete("movies","id='"+id+"'", null) > 0;
        db.close();
        return deleteSuccessful;
    }
}